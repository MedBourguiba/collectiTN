<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_e81cff2a485b4e67e119ce164375c31d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'css' => [$this, 'block_css'],
            'StyleAfterTemplate' => [$this, 'block_StyleAfterTemplate'],
            'body' => [$this, 'block_body'],
            'footer' => [$this, 'block_footer'],
            'js' => [$this, 'block_js'],
            'JsAfterTemplate' => [$this, 'block_JsAfterTemplate'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!doctype html>
<html class=\"no-js\" lang=\"en\">
    <head>
        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
      
       <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title> 
      
        <meta name=\"description\" content=\"\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
       ";
        // line 11
        $this->displayBlock('css', $context, $blocks);
        // line 16
        echo "       ";
        $this->displayBlock('StyleAfterTemplate', $context, $blocks);
        // line 17
        echo "        <!--[if lt IE 9]>
            <script src=\"//html5shiv.googlecode.com/svn/trunk/html5.js\"></script>
            <script>window.html5 || document.write('<script src=\"js/vendor/html5shiv.js\"><\\/script>')</script>
        <![endif]-->
    </head>
    <body>

        <!-- PRELOADER -->
        <div id=\"preloader\">
            <div class=\"preloader-area\">
            \t<div class=\"preloader-box\">
            \t\t<div class=\"preloader\"></div>
            \t</div>
            </div>
        </div>


        <section class=\"header-top-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div  class=\"col-md-6\">
                        <div class=\"header-top-content\">
                            <ul class=\"nav nav-pills navbar-left\">
                                <li><a href=\"#\"><i class=\"pe-7s-call\"></i><span>123-123456789</span></a></li>
                                <li><a href=\"#\"><i class=\"pe-7s-mail\"></i><span> info@mart.com</span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div  class=\"col-md-6\">
                        <div class=\"header-top-menu\">
                            <ul class=\"nav nav-pills navbar-right\">
                                <li><a href=\"#\">My Account</a></li>
                                <li><a href=\"#\">Wishlist</a></li>
                                <li><a href=\"#\">Cart</a></li>
                                <li><a href=\"#\">Checkout</a></li>
                                <li><a href=\"#\"><i class=\"pe-7s-lock\"></i>Login/Register</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <header class=\"header-section\">
            <nav class=\"navbar navbar-default\">
                <div class=\"container\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                            <span class=\"sr-only\">Toggle navigation</span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                        </button>
                        <a class=\"navbar-brand\" href=\"#\"><b>M</b>art</a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                        <ul class=\"nav navbar-nav\">
                            <li class=\"active\"><a href=\"#\">Home</a></li>
                            <li><a href=\"#\">About Us</a></li>
                            <li><a href=\"#\">page</a></li>
                            <li><a href=\"#\">shop</a></li>
                            <li><a href=\"#\">Blog</a></li>
                            <li><a href=\"#\">Contact Us</a></li>
                        </ul>
                        <ul class=\"nav navbar-nav navbar-right cart-menu\">
                        <li><a href=\"#\" class=\"search-btn\"><i class=\"fa fa-search\" aria-hidden=\"true\"></i></a></li>
                        <li><a href=\"#\"><span> Cart -\$0&nbsp;</span> <span class=\"shoping-cart\">0</span></a></li>
                    </ul>
                    </div><!-- /.navbar-collapse -->
                </div><!-- /.container -->
            </nav>
        </header>

        <section class=\"search-section\">
            <div class=\"container\">
                <div class=\"row subscribe-from\">
                    <div class=\"col-md-12\">
                        <form class=\"form-inline col-md-12 wow fadeInDown animated\">
                            <div class=\"form-group\">
                                <input type=\"email\" class=\"form-control subscribe\" id=\"email\" placeholder=\"Search...\">
                                <button class=\"suscribe-btn\" ><i class=\"pe-7s-search\"></i></button>
                            </div>
                        </form><!-- end /. form -->
                    </div>
                </div><!-- end of/. row -->
            </div><!-- end of /.container -->
        </section><!-- end of /.news letter section -->
     ";
        // line 107
        $this->displayBlock('body', $context, $blocks);
        // line 836
        echo "    ";
        $this->displayBlock('footer', $context, $blocks);
        // line 848
        echo "        <!-- JQUERY -->
        ";
        // line 849
        $this->displayBlock('js', $context, $blocks);
        // line 857
        echo "        ";
        $this->displayBlock('JsAfterTemplate', $context, $blocks);
        // line 860
        echo "    </body>
</html>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 7
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo " Mart - HTML5 Resoponsive onepage e-commerce template ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 11
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        // line 12
        echo "        <link rel=\"icon\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/favicon.png"), "html", null, true);
        echo "\">

        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/css/style.css"), "html", null, true);
        echo "\">
       ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 16
    public function block_StyleAfterTemplate($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "StyleAfterTemplate"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "StyleAfterTemplate"));

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 107
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 108
        echo "        <section class=\"slider-section\">
            <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
                <!-- Indicators -->
                <ol class=\"carousel-indicators slider-indicators\">
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"0\" class=\"active\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"1\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"2\"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class=\"carousel-inner\" role=\"listbox\">
                    <div class=\"item active\">
                        <img src=\"";
        // line 120
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/slider.jpg"), "html", null, true);
        echo "\" width=\"1648\" height=\"600\" alt=\"\">
                        <div class=\"carousel-caption\">
                            <h2>DRESSES <b>&</b> JEANS</h2>
                            <h3>FROM OURFAMOUS BRANDS <Span>SALE</Span></h3>
                            <a href=\"#\">Buy Now</a>
                        </div>
                    </div>
                    <div class=\"item\">
                        <img src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/slider.jpg"), "html", null, true);
        echo "\" width=\"1648\" height=\"600\" alt=\"\">
                        <div class=\"carousel-caption\">
                            <h2>DRESSES <b>&</b> JEANS</h2>
                            <h3>FROM OURFAMOUS BRANDS <Span>SALE</Span></h3>
                            <a href=\"#\">Buy Now</a>
                        </div>
                    </div>
                    <div class=\"item \">
                        <img src=\"";
        // line 136
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/slider.jpg"), "html", null, true);
        echo "\" width=\"1648\" height=\"600\" alt=\"\">
                        <div class=\"carousel-caption\">
                            <h2>DRESSES <b>&</b> JEANS</h2>
                            <h3>FROM OURFAMOUS BRANDS <Span>SALE</Span></h3>
                            <a href=\"#\">Buy Now</a>
                        </div>
                    </div>
                </div>

                <!-- Controls -->
                <a class=\"left carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"prev\">
                    <span class=\"pe-7s-angle-left glyphicon-chevron-left\" aria-hidden=\"true\"></span>
                </a>
                <a class=\"right carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"next\">
                    <span class=\"pe-7s-angle-right glyphicon-chevron-right\" aria-hidden=\"true\"></span>
                </a>
            </div>
        </section>

        <section class=\"service-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-3 col-sm-6 wow fadeInRight animated\" data-wow-delay=\"0.1s\">
                        <div class=\"service-item\">
                            <i class=\"pe-7s-settings\"></i>
                            <h3>SETTING</h3>
                            <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInRight animated\" data-wow-delay=\"0.2s\">
                        <div class=\"service-item\">
                            <i class=\"pe-7s-safe\"></i>
                            <h3>MONEY BACK</h3>
                            <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInRight animated\" data-wow-delay=\"0.3s\">
                        <div class=\"service-item\">
                            <i class=\"pe-7s-global\"></i>
                            <h3>WORLDWIDE SHIPPING</h3>
                            <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInRight animated\" data-wow-delay=\"0.4s\">
                        <div class=\"service-item\">
                            <i class=\"pe-7s-headphones\"></i>
                            <h3>Online support</h3>
                            <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"new-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>NEW COLLECTION</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-3 col-sm-6 wow fadeInLeft animated\" data-wow-delay=\"0.2s\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 202
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/1.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Blue Tshirt</h3>
                                    <span>\$26</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInLeft animated\" data-wow-delay=\"0.4s\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 221
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/2.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>WOMAN shirt</h3>
                                    <span>\$31</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInLeft animated\" data-wow-delay=\"0.6s\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 240
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/3.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>YELLOW Tshirt</h3>
                                    <span>\$21</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInLeft animated\" data-wow-delay=\"0.8s\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 259
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/4.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$56</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"featured-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>FEATURED PRODUCTS</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"filter-menu\">
                            <ul class=\"button-group sort-button-group\">
                                <li class=\"button active\" data-category=\"all\">All<span>8</span></li>
                                <li class=\"button\" data-category=\"cat-1\">Dresses and Suits<span>2</span></li>
                                <li class=\"button\" data-category=\"cat-2\">Accessories<span>2</span></li>
                                <li class=\"button\" data-category=\"cat-3\">Miscellaneous<span>4</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class=\"row featured isotope\">
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-3 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 304
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/product1.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"new-item\">New</a>
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$26</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-2 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 327
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/product2.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"new-item\">New</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$21</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-1 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 349
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/product3.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"new-item\">New</a>
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$31</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-3 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 372
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/product4.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$56</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-2 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 394
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/product5.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$26</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-3 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 416
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/product6.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"new-item\">New</a>
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$36</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-1 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 439
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/product7.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"new-item\">New</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$56</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-3 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 461
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/product8.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$66</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"offer-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12 wow fadeInDown animated \">
                        <h1>END OF SEASON SALE</h1>
                        <h2>Up to 35% off Women's Denim</h2>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"best-seller-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>BEST SELLERS</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-3 col-sm-6 wow fadeInDown animated\" data-wow-delay=\"0.2s\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 508
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/1.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Blue Tshirt</h3>
                                    <span>\$26</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInDown animated\" data-wow-delay=\"0.4s\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 527
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/2.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>WOMAN shirt</h3>
                                    <span>\$31</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInDown animated\" data-wow-delay=\"0.6s\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 546
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/3.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>YELLOW Tshirt</h3>
                                    <span>\$21</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInDown animated\" data-wow-delay=\"0.8s\">
                        <div class=\"product-item\">
                            <img src=\"";
        // line 565
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/4.png"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$56</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"review-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>customer review</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div id=\"feedback\" class=\"carousel slide feedback\" data-ride=\"feedback\">
                        <!-- Wrapper for slides -->
                        <div class=\"carousel-inner\" role=\"listbox\">
                            <div class=\"item active\">
                                <img src=\"";
        // line 600
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/member1.png"), "html", null, true);
        echo "\" width=\"320\" height=\"439\" alt=\"\">
                                <div class=\"carousel-caption\">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, </p>
                                    <h3>- Olivia -</h3>
                                    <span>Melbour, Aus</span>
                                </div>
                            </div>
                            <div class=\"item\">
                                <img src=\"";
        // line 608
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/member2.png"), "html", null, true);
        echo "\" width=\"320\" height=\"439\" alt=\"\">
                                <div class=\"carousel-caption\">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, </p>
                                    <h3>- Olivia -</h3>
                                    <span>Melbour, Aus</span>
                                </div>
                            </div>
                            <div class=\"item\">
                                <img src=\"";
        // line 616
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/member3.png"), "html", null, true);
        echo "\" width=\"320\" height=\"439\" alt=\"\">
                                <div class=\"carousel-caption\">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, </p>
                                    <h3>- Olivia -</h3>
                                    <span>Melbour, Aus</span>
                                </div>
                            </div>
                        </div>
                        <!-- Indicators -->
                        <ol class=\"carousel-indicators review-controlar\">
                            <li data-target=\"#feedback\" data-slide-to=\"0\" class=\"active\">
                                <img src=\"";
        // line 627
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/member1.png"), "html", null, true);
        echo "\" width=\"320\" height=\"439\" alt=\"\">
                            </li>
                            <li data-target=\"#feedback\" data-slide-to=\"1\">
                                <img src=\"";
        // line 630
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/member2.png"), "html", null, true);
        echo "\" width=\"320\" height=\"439\" alt=\"\">
                            </li>
                            <li data-target=\"#feedback\" data-slide-to=\"2\">
                                <img src=\"";
        // line 633
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/member3.png"), "html", null, true);
        echo "\" width=\"320\" height=\"439\" alt=\"\">
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"news-letter-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"titie-section white wow fadeInDown animated \">
                            <h1>NEWSLETTER</h1>
                        </div>
                        <p>Follow a collection of news & promotions</p>
                    </div>
                </div>
                <div class=\"row subscribe-from\">
                    <form class=\"form-inline col-md-6 col-md-offset-3 col-xs-10 col-xs-offset-1  wow fadeInDown animated\">
                        <div class=\"form-group\">
                            <input type=\"email\" class=\"form-control subscribe\" id=\"email\" placeholder=\"Enter your email\">
                            <button class=\"suscribe-btn\" ><i class=\"pe-7s-next\"></i></button>
                        </div>
                    </form><!-- end /. form -->
                </div><!-- end of/. row -->
            </div><!-- end of /.container -->
        </section><!-- end of /.news letter section -->

        <section class=\"client-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>our partner</h1>
                        </div>
                    </div>
                </div>
                <div id=\"client\" class=\"row owl-carousel owl-theme client-area\">
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"";
        // line 674
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/client_01.jpg"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"";
        // line 679
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/client_02.jpg"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"";
        // line 684
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/client_03.jpg"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"";
        // line 689
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/client_04.jpg"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"";
        // line 694
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/client_01.jpg"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"";
        // line 699
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/client_02.jpg"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"";
        // line 704
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/client_03.jpg"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"";
        // line 709
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/client_04.jpg"), "html", null, true);
        echo "\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                </div>
                <div class=\"customNavigation works-navigation\">
                    <a class=\"btn-work works-prev\"><i class=\"pe-7s-angle-left\"></i></a>
                    <a class=\"btn-work works-next\"><i class=\"pe-7s-angle-right\"></i></a>
                </div><!-- end of /.client navigation -->
            </div>
        </section>

        <section class=\"news-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>Latest News</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\" >
                    <div class=\"col-sm-4 wow fadeInDown animated\" data-wow-delay=\"0.2s\">
                        <div class=\"blog-item\">
                            <a href=\"#\"><img src=\"";
        // line 732
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/blog1.jpg"), "html", null, true);
        echo "\" width=\"350\" height=\"262\" alt=\"\"></a>
                            <h3>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean </h3>
                            <p>Nam nec tellus a odio tincidunt auc. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt</p>
                            <a href=\"#\">Read More</a>
                        </div>
                    </div>
                    <div class=\"col-sm-4 wow fadeInDown animated\" data-wow-delay=\"0.4s\">
                        <div class=\"blog-item\">
                            <a href=\"#\"><img src=\"";
        // line 740
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/blog2.jpg"), "html", null, true);
        echo "\" width=\"350\" height=\"262\" alt=\"\"></a>
                            <h3>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean </h3>
                            <p>Nam nec tellus a odio tincidunt auc. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt</p>
                            <a href=\"#\">Read More</a>

                        </div>
                    </div>
                    <div class=\"col-sm-4 wow fadeInDown animated\" data-wow-delay=\"0.6s\">
                        <div class=\"blog-item\">
                            <a href=\"#\"><img src=\"";
        // line 749
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/blog3.jpg"), "html", null, true);
        echo "\" width=\"350\" height=\"262\" alt=\"\"></a>
                            <h3>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean </h3>
                            <p>Nam nec tellus a odio tincidunt auc. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt</p>
                            <a href=\"#\">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"contact-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>GET IN TOUCH</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-6 wow fadeInLeft animated\">
                        <div class=\"left-content\">
                            <h1><span>M</span>art</h1>
                            <h3>We'd love To Meet You In Person Or Via The Web!</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel nulla sapien. Class aptent tacitiaptent taciti sociosqu ad lit himenaeos. Suspendisse massa urna, luctus ut vestibulum necs et, vulputate quis urna. Donec at commodo erat.</p>
                            <div class=\"contact-info\">
                                <p><b>Main Office:</b> 123 Elm St. New York City, NY</p>
                                <p><b>Phone:</b> 1.555.555.5555</p>
                                <p><b>Email:</b> info@yourdomain.com</p>
                            </div>
                            <div class=\"social-media\">
                                <ul>
                                    <li><a href=\"#\"><i class=\"fa fa-facebook\"></i></a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-twitter\"></i></a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-dribbble\"></i></a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-linkedin\"></i></a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-instagram\"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-6 wow fadeInRight animated\">
                        <form action=\"\" method=\"\" class=\"contact-form\">
                            <div class=\"row\">
                                <div class=\"col-md-6\">
                                    <div class=\"input-group\">
                                        <input type=\"text\" class=\"form-control\" id=\"name\" placeholder=\"Your Name\">
                                    </div>
                                </div>
                                <div class=\"col-md-6\">
                                    <div class=\"input-group\">
                                        <input type=\"text\" class=\"form-control\" id=\"name\" placeholder=\"Your Email\">
                                    </div>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"col-md-6\">
                                    <div class=\"input-group\">
                                        <input type=\"text\" class=\"form-control\" id=\"name\" placeholder=\"Subject\">
                                    </div>
                                </div>
                                <div class=\"col-md-6\">
                                    <div class=\"input-group\">
                                        <input type=\"text\" class=\"form-control\" id=\"name\" placeholder=\"Website URL\">
                                    </div>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <div class=\"input-group\">
                                        <textarea name=\"\" id=\"\" class=\"form-control\" cols=\"30\" rows=\"5\" placeholder=\"Your Message...\"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <div class=\"input-group\">
                                        <input type=\"submit\" class=\"contact-submit\" value=\"Send\" />
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 836
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 837
        echo "        <footer class=\"footer\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <p class=\"center\">Designed By <i class=\"fa fa-love\"></i><a href=\"#\">Pi Esprit</a></p>
                        
                    </div>
                </div>
            </div>
        </footer>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 849
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        // line 850
        echo "        <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/js/vendor/jquery-1.11.2.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 851
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/js/vendor/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 852
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/js/isotope.pkgd.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 853
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/js/owl.carousel.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 854
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/js/wow.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 855
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/js/custom.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 857
    public function block_JsAfterTemplate($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "JsAfterTemplate"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "JsAfterTemplate"));

        // line 858
        echo "
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  1190 => 858,  1180 => 857,  1168 => 855,  1164 => 854,  1160 => 853,  1156 => 852,  1152 => 851,  1147 => 850,  1137 => 849,  1117 => 837,  1107 => 836,  1010 => 749,  998 => 740,  987 => 732,  961 => 709,  953 => 704,  945 => 699,  937 => 694,  929 => 689,  921 => 684,  913 => 679,  905 => 674,  861 => 633,  855 => 630,  849 => 627,  835 => 616,  824 => 608,  813 => 600,  775 => 565,  753 => 546,  731 => 527,  709 => 508,  659 => 461,  634 => 439,  608 => 416,  583 => 394,  558 => 372,  532 => 349,  507 => 327,  481 => 304,  433 => 259,  411 => 240,  389 => 221,  367 => 202,  298 => 136,  287 => 128,  276 => 120,  262 => 108,  252 => 107,  234 => 16,  222 => 14,  216 => 12,  206 => 11,  187 => 7,  175 => 860,  172 => 857,  170 => 849,  167 => 848,  164 => 836,  162 => 107,  70 => 17,  67 => 16,  65 => 11,  58 => 7,  50 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!doctype html>
<html class=\"no-js\" lang=\"en\">
    <head>
        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
      
       <title>{% block title %} Mart - HTML5 Resoponsive onepage e-commerce template {% endblock %}</title> 
      
        <meta name=\"description\" content=\"\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
       {% block css %}
        <link rel=\"icon\" href=\"{{asset('front-office/images/favicon.png')}}\">

        <link rel=\"stylesheet\" href=\"{{asset('front-office/css/style.css')}}\">
       {% endblock %}
       {% block StyleAfterTemplate %}{% endblock StyleAfterTemplate %}
        <!--[if lt IE 9]>
            <script src=\"//html5shiv.googlecode.com/svn/trunk/html5.js\"></script>
            <script>window.html5 || document.write('<script src=\"js/vendor/html5shiv.js\"><\\/script>')</script>
        <![endif]-->
    </head>
    <body>

        <!-- PRELOADER -->
        <div id=\"preloader\">
            <div class=\"preloader-area\">
            \t<div class=\"preloader-box\">
            \t\t<div class=\"preloader\"></div>
            \t</div>
            </div>
        </div>


        <section class=\"header-top-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div  class=\"col-md-6\">
                        <div class=\"header-top-content\">
                            <ul class=\"nav nav-pills navbar-left\">
                                <li><a href=\"#\"><i class=\"pe-7s-call\"></i><span>123-123456789</span></a></li>
                                <li><a href=\"#\"><i class=\"pe-7s-mail\"></i><span> info@mart.com</span></a></li>
                            </ul>
                        </div>
                    </div>
                    <div  class=\"col-md-6\">
                        <div class=\"header-top-menu\">
                            <ul class=\"nav nav-pills navbar-right\">
                                <li><a href=\"#\">My Account</a></li>
                                <li><a href=\"#\">Wishlist</a></li>
                                <li><a href=\"#\">Cart</a></li>
                                <li><a href=\"#\">Checkout</a></li>
                                <li><a href=\"#\"><i class=\"pe-7s-lock\"></i>Login/Register</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <header class=\"header-section\">
            <nav class=\"navbar navbar-default\">
                <div class=\"container\">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class=\"navbar-header\">
                        <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
                            <span class=\"sr-only\">Toggle navigation</span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                            <span class=\"icon-bar\"></span>
                        </button>
                        <a class=\"navbar-brand\" href=\"#\"><b>M</b>art</a>
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                        <ul class=\"nav navbar-nav\">
                            <li class=\"active\"><a href=\"#\">Home</a></li>
                            <li><a href=\"#\">About Us</a></li>
                            <li><a href=\"#\">page</a></li>
                            <li><a href=\"#\">shop</a></li>
                            <li><a href=\"#\">Blog</a></li>
                            <li><a href=\"#\">Contact Us</a></li>
                        </ul>
                        <ul class=\"nav navbar-nav navbar-right cart-menu\">
                        <li><a href=\"#\" class=\"search-btn\"><i class=\"fa fa-search\" aria-hidden=\"true\"></i></a></li>
                        <li><a href=\"#\"><span> Cart -\$0&nbsp;</span> <span class=\"shoping-cart\">0</span></a></li>
                    </ul>
                    </div><!-- /.navbar-collapse -->
                </div><!-- /.container -->
            </nav>
        </header>

        <section class=\"search-section\">
            <div class=\"container\">
                <div class=\"row subscribe-from\">
                    <div class=\"col-md-12\">
                        <form class=\"form-inline col-md-12 wow fadeInDown animated\">
                            <div class=\"form-group\">
                                <input type=\"email\" class=\"form-control subscribe\" id=\"email\" placeholder=\"Search...\">
                                <button class=\"suscribe-btn\" ><i class=\"pe-7s-search\"></i></button>
                            </div>
                        </form><!-- end /. form -->
                    </div>
                </div><!-- end of/. row -->
            </div><!-- end of /.container -->
        </section><!-- end of /.news letter section -->
     {% block body %}
        <section class=\"slider-section\">
            <div id=\"carousel-example-generic\" class=\"carousel slide\" data-ride=\"carousel\">
                <!-- Indicators -->
                <ol class=\"carousel-indicators slider-indicators\">
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"0\" class=\"active\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"1\"></li>
                    <li data-target=\"#carousel-example-generic\" data-slide-to=\"2\"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class=\"carousel-inner\" role=\"listbox\">
                    <div class=\"item active\">
                        <img src=\"{{asset('front-office/images/slider.jpg')}}\" width=\"1648\" height=\"600\" alt=\"\">
                        <div class=\"carousel-caption\">
                            <h2>DRESSES <b>&</b> JEANS</h2>
                            <h3>FROM OURFAMOUS BRANDS <Span>SALE</Span></h3>
                            <a href=\"#\">Buy Now</a>
                        </div>
                    </div>
                    <div class=\"item\">
                        <img src=\"{{asset('front-office/images/slider.jpg')}}\" width=\"1648\" height=\"600\" alt=\"\">
                        <div class=\"carousel-caption\">
                            <h2>DRESSES <b>&</b> JEANS</h2>
                            <h3>FROM OURFAMOUS BRANDS <Span>SALE</Span></h3>
                            <a href=\"#\">Buy Now</a>
                        </div>
                    </div>
                    <div class=\"item \">
                        <img src=\"{{asset('front-office/images/slider.jpg')}}\" width=\"1648\" height=\"600\" alt=\"\">
                        <div class=\"carousel-caption\">
                            <h2>DRESSES <b>&</b> JEANS</h2>
                            <h3>FROM OURFAMOUS BRANDS <Span>SALE</Span></h3>
                            <a href=\"#\">Buy Now</a>
                        </div>
                    </div>
                </div>

                <!-- Controls -->
                <a class=\"left carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"prev\">
                    <span class=\"pe-7s-angle-left glyphicon-chevron-left\" aria-hidden=\"true\"></span>
                </a>
                <a class=\"right carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"next\">
                    <span class=\"pe-7s-angle-right glyphicon-chevron-right\" aria-hidden=\"true\"></span>
                </a>
            </div>
        </section>

        <section class=\"service-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-3 col-sm-6 wow fadeInRight animated\" data-wow-delay=\"0.1s\">
                        <div class=\"service-item\">
                            <i class=\"pe-7s-settings\"></i>
                            <h3>SETTING</h3>
                            <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInRight animated\" data-wow-delay=\"0.2s\">
                        <div class=\"service-item\">
                            <i class=\"pe-7s-safe\"></i>
                            <h3>MONEY BACK</h3>
                            <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInRight animated\" data-wow-delay=\"0.3s\">
                        <div class=\"service-item\">
                            <i class=\"pe-7s-global\"></i>
                            <h3>WORLDWIDE SHIPPING</h3>
                            <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInRight animated\" data-wow-delay=\"0.4s\">
                        <div class=\"service-item\">
                            <i class=\"pe-7s-headphones\"></i>
                            <h3>Online support</h3>
                            <p>Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"new-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>NEW COLLECTION</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-3 col-sm-6 wow fadeInLeft animated\" data-wow-delay=\"0.2s\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/1.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Blue Tshirt</h3>
                                    <span>\$26</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInLeft animated\" data-wow-delay=\"0.4s\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/2.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>WOMAN shirt</h3>
                                    <span>\$31</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInLeft animated\" data-wow-delay=\"0.6s\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/3.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>YELLOW Tshirt</h3>
                                    <span>\$21</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInLeft animated\" data-wow-delay=\"0.8s\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/4.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$56</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"featured-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>FEATURED PRODUCTS</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"filter-menu\">
                            <ul class=\"button-group sort-button-group\">
                                <li class=\"button active\" data-category=\"all\">All<span>8</span></li>
                                <li class=\"button\" data-category=\"cat-1\">Dresses and Suits<span>2</span></li>
                                <li class=\"button\" data-category=\"cat-2\">Accessories<span>2</span></li>
                                <li class=\"button\" data-category=\"cat-3\">Miscellaneous<span>4</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class=\"row featured isotope\">
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-3 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/product1.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"new-item\">New</a>
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$26</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-2 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/product2.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"new-item\">New</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$21</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-1 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/product3.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"new-item\">New</a>
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$31</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-3 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/product4.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$56</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-2 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/product5.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$26</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-3 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/product6.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"new-item\">New</a>
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$36</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-1 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/product7.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"new-item\">New</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$56</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 col-xs-12 cat-3 featured-items isotope-item\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/product8.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"sell-meta\">
                                <a href=\"#\" class=\"sell-item\">Sell</a>
                            </div>
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$66</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"offer-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12 wow fadeInDown animated \">
                        <h1>END OF SEASON SALE</h1>
                        <h2>Up to 35% off Women's Denim</h2>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"best-seller-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>BEST SELLERS</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-3 col-sm-6 wow fadeInDown animated\" data-wow-delay=\"0.2s\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/1.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Blue Tshirt</h3>
                                    <span>\$26</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInDown animated\" data-wow-delay=\"0.4s\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/2.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>WOMAN shirt</h3>
                                    <span>\$31</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInDown animated\" data-wow-delay=\"0.6s\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/3.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>YELLOW Tshirt</h3>
                                    <span>\$21</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-3 col-sm-6 wow fadeInDown animated\" data-wow-delay=\"0.8s\">
                        <div class=\"product-item\">
                            <img src=\"{{asset('front-office/images/4.png')}}\" class=\"img-responsive\" width=\"255\" height=\"322\" alt=\"\">
                            <div class=\"product-hover\">
                                <div class=\"product-meta\">
                                    <a href=\"#\"><i class=\"pe-7s-like\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-shuffle\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-clock\"></i></a>
                                    <a href=\"#\"><i class=\"pe-7s-cart\"></i>Add to Cart</a>
                                </div>
                            </div>
                            <div class=\"product-title\">
                                <a href=\"#\">
                                    <h3>Cool lingerie</h3>
                                    <span>\$56</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"review-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>customer review</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div id=\"feedback\" class=\"carousel slide feedback\" data-ride=\"feedback\">
                        <!-- Wrapper for slides -->
                        <div class=\"carousel-inner\" role=\"listbox\">
                            <div class=\"item active\">
                                <img src=\"{{asset('front-office/images/member1.png')}}\" width=\"320\" height=\"439\" alt=\"\">
                                <div class=\"carousel-caption\">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, </p>
                                    <h3>- Olivia -</h3>
                                    <span>Melbour, Aus</span>
                                </div>
                            </div>
                            <div class=\"item\">
                                <img src=\"{{asset('front-office/images/member2.png')}}\" width=\"320\" height=\"439\" alt=\"\">
                                <div class=\"carousel-caption\">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, </p>
                                    <h3>- Olivia -</h3>
                                    <span>Melbour, Aus</span>
                                </div>
                            </div>
                            <div class=\"item\">
                                <img src=\"{{asset('front-office/images/member3.png')}}\" width=\"320\" height=\"439\" alt=\"\">
                                <div class=\"carousel-caption\">
                                    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, </p>
                                    <h3>- Olivia -</h3>
                                    <span>Melbour, Aus</span>
                                </div>
                            </div>
                        </div>
                        <!-- Indicators -->
                        <ol class=\"carousel-indicators review-controlar\">
                            <li data-target=\"#feedback\" data-slide-to=\"0\" class=\"active\">
                                <img src=\"{{asset('front-office/images/member1.png')}}\" width=\"320\" height=\"439\" alt=\"\">
                            </li>
                            <li data-target=\"#feedback\" data-slide-to=\"1\">
                                <img src=\"{{asset('front-office/images/member2.png')}}\" width=\"320\" height=\"439\" alt=\"\">
                            </li>
                            <li data-target=\"#feedback\" data-slide-to=\"2\">
                                <img src=\"{{asset('front-office/images/member3.png')}}\" width=\"320\" height=\"439\" alt=\"\">
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"news-letter-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"titie-section white wow fadeInDown animated \">
                            <h1>NEWSLETTER</h1>
                        </div>
                        <p>Follow a collection of news & promotions</p>
                    </div>
                </div>
                <div class=\"row subscribe-from\">
                    <form class=\"form-inline col-md-6 col-md-offset-3 col-xs-10 col-xs-offset-1  wow fadeInDown animated\">
                        <div class=\"form-group\">
                            <input type=\"email\" class=\"form-control subscribe\" id=\"email\" placeholder=\"Enter your email\">
                            <button class=\"suscribe-btn\" ><i class=\"pe-7s-next\"></i></button>
                        </div>
                    </form><!-- end /. form -->
                </div><!-- end of/. row -->
            </div><!-- end of /.container -->
        </section><!-- end of /.news letter section -->

        <section class=\"client-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>our partner</h1>
                        </div>
                    </div>
                </div>
                <div id=\"client\" class=\"row owl-carousel owl-theme client-area\">
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"{{asset('front-office/images/client_01.jpg')}}\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"{{asset('front-office/images/client_02.jpg')}}\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"{{asset('front-office/images/client_03.jpg')}}\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"{{asset('front-office/images/client_04.jpg')}}\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"{{asset('front-office/images/client_01.jpg')}}\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"{{asset('front-office/images/client_02.jpg')}}\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"{{asset('front-office/images/client_03.jpg')}}\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                    <div class=\"col-md-12 item\">
                        <a href=\"#\">
                            <img src=\"{{asset('front-office/images/client_04.jpg')}}\" class=\"img-responsive\" width=\"300\" height=\"200\" alt=\"\">
                        </a>
                    </div>
                </div>
                <div class=\"customNavigation works-navigation\">
                    <a class=\"btn-work works-prev\"><i class=\"pe-7s-angle-left\"></i></a>
                    <a class=\"btn-work works-next\"><i class=\"pe-7s-angle-right\"></i></a>
                </div><!-- end of /.client navigation -->
            </div>
        </section>

        <section class=\"news-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>Latest News</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\" >
                    <div class=\"col-sm-4 wow fadeInDown animated\" data-wow-delay=\"0.2s\">
                        <div class=\"blog-item\">
                            <a href=\"#\"><img src=\"{{asset('front-office/images/blog1.jpg')}}\" width=\"350\" height=\"262\" alt=\"\"></a>
                            <h3>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean </h3>
                            <p>Nam nec tellus a odio tincidunt auc. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt</p>
                            <a href=\"#\">Read More</a>
                        </div>
                    </div>
                    <div class=\"col-sm-4 wow fadeInDown animated\" data-wow-delay=\"0.4s\">
                        <div class=\"blog-item\">
                            <a href=\"#\"><img src=\"{{asset('front-office/images/blog2.jpg')}}\" width=\"350\" height=\"262\" alt=\"\"></a>
                            <h3>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean </h3>
                            <p>Nam nec tellus a odio tincidunt auc. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt</p>
                            <a href=\"#\">Read More</a>

                        </div>
                    </div>
                    <div class=\"col-sm-4 wow fadeInDown animated\" data-wow-delay=\"0.6s\">
                        <div class=\"blog-item\">
                            <a href=\"#\"><img src=\"{{asset('front-office/images/blog3.jpg')}}\" width=\"350\" height=\"262\" alt=\"\"></a>
                            <h3>Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean </h3>
                            <p>Nam nec tellus a odio tincidunt auc. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris. Morbi accumsan ipsum velit. Nam nec tellus a odio tincidunt</p>
                            <a href=\"#\">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class=\"contact-section\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-sm-12\">
                        <div class=\"titie-section wow fadeInDown animated \">
                            <h1>GET IN TOUCH</h1>
                        </div>
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-6 wow fadeInLeft animated\">
                        <div class=\"left-content\">
                            <h1><span>M</span>art</h1>
                            <h3>We'd love To Meet You In Person Or Via The Web!</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel nulla sapien. Class aptent tacitiaptent taciti sociosqu ad lit himenaeos. Suspendisse massa urna, luctus ut vestibulum necs et, vulputate quis urna. Donec at commodo erat.</p>
                            <div class=\"contact-info\">
                                <p><b>Main Office:</b> 123 Elm St. New York City, NY</p>
                                <p><b>Phone:</b> 1.555.555.5555</p>
                                <p><b>Email:</b> info@yourdomain.com</p>
                            </div>
                            <div class=\"social-media\">
                                <ul>
                                    <li><a href=\"#\"><i class=\"fa fa-facebook\"></i></a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-twitter\"></i></a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-dribbble\"></i></a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-linkedin\"></i></a></li>
                                    <li><a href=\"#\"><i class=\"fa fa-instagram\"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class=\"col-md-6 wow fadeInRight animated\">
                        <form action=\"\" method=\"\" class=\"contact-form\">
                            <div class=\"row\">
                                <div class=\"col-md-6\">
                                    <div class=\"input-group\">
                                        <input type=\"text\" class=\"form-control\" id=\"name\" placeholder=\"Your Name\">
                                    </div>
                                </div>
                                <div class=\"col-md-6\">
                                    <div class=\"input-group\">
                                        <input type=\"text\" class=\"form-control\" id=\"name\" placeholder=\"Your Email\">
                                    </div>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"col-md-6\">
                                    <div class=\"input-group\">
                                        <input type=\"text\" class=\"form-control\" id=\"name\" placeholder=\"Subject\">
                                    </div>
                                </div>
                                <div class=\"col-md-6\">
                                    <div class=\"input-group\">
                                        <input type=\"text\" class=\"form-control\" id=\"name\" placeholder=\"Website URL\">
                                    </div>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <div class=\"input-group\">
                                        <textarea name=\"\" id=\"\" class=\"form-control\" cols=\"30\" rows=\"5\" placeholder=\"Your Message...\"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class=\"row\">
                                <div class=\"col-md-12\">
                                    <div class=\"input-group\">
                                        <input type=\"submit\" class=\"contact-submit\" value=\"Send\" />
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        {% endblock %}
    {% block footer %}
        <footer class=\"footer\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        <p class=\"center\">Designed By <i class=\"fa fa-love\"></i><a href=\"#\">Pi Esprit</a></p>
                        
                    </div>
                </div>
            </div>
        </footer>
{% endblock %}
        <!-- JQUERY -->
        {% block js%}
        <script src=\"{{asset('front-office/js/vendor/jquery-1.11.2.min.js')}}\"></script>
        <script src=\"{{asset('front-office/js/vendor/bootstrap.min.js')}}\"></script>
        <script src=\"{{asset('front-office/js/isotope.pkgd.min.js')}}\"></script>
        <script src=\"{{asset('front-office/js/owl.carousel.min.js')}}\"></script>
        <script src=\"{{asset('front-office/js/wow.min.js')}}\"></script>
        <script src=\"{{asset('front-office/js/custom.js')}}\"></script>
        {% endblock %}
        {% block JsAfterTemplate %}

        {% endblock JsAfterTemplate %}
    </body>
</html>
", "base.html.twig", "/home/ilyes/Documents/Pi_ModuleEvenement_Offre_Farah/templates/base.html.twig");
    }
}
