<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* evenement/index.html.twig */
class __TwigTemplate_e7159006da617f1a4310cae5c38e3323 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'StyleAfterTemplate' => [$this, 'block_StyleAfterTemplate'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "evenement/index.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "evenement/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "evenement/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Evenement";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 4
    public function block_StyleAfterTemplate($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "StyleAfterTemplate"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "StyleAfterTemplate"));

        // line 5
        echo "<link href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
<link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("https://fonts.googleapis.com/icon?family=Material+Icons"), "html", null, true);
        echo "\">
<style>
    /* Table actions icons*/
    table.table td a.view {
        color: #03A9F4;
    }

    table.table td a.edit {
        color: #FFC107;
    }

    table.table td a.delete {
        color: #E34724;
        text-align: center;
    }

    .hint-text {
        float: left;
        margin-top: 6px;
        font-size: 95%;
    }
</style>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 30
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 31
        echo "<div class=\"row justify-content-md-center\">

    <div class=\"col-lg-11\">
        <div class=\"card o-hidden border-0 shadow-lg my-5\">
            <div class=\"card-body p-0\">
                <div class=\"p-5\">
                    <div class=\"text-center\">
                        <h1 class=\"h4 text-gray-900 mb-4\">Les Evenements</h1>
                    </div>
                    <a href=\"";
        // line 40
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AjouterEvent");
        echo "\" class=\"btn btn-success btn float-right col-sm col-md-3\">
                        <span class=\"icon text-white-50\">
                            <i style=\"float: left;\" class=\"material-icons mr-2\">&#xE147;</i>
                        </span>
                        <span class=\"text\">Ajouter un evenement</span>
                    </a>
                    <div class=\"table-responsive-sm mt-4\">
                        <div class=\"d-none d-sm-inline-block form-inline navbar-search\">

                        </div>
                        <br>
                        <br>
                        <table class=\"table table-hover \" id=\"myTable\">
                            <thead class=\"thead-light \">
                                <tr>
                                    <th scope=\"col\">Nom</th>
                                    <th scope=\"col\">nombre de places</th>
                                    <th scope=\"col\">type</th>
                                    <th scope=\"col\">prix</th>
                                    <th scope=\"col\">Date</th>
                                    <th scope=\"col\">Action</th>
                                </tr>
                            </thead>
                            <tbody id=\"myTable\">
                                ";
        // line 64
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["evenementss"]) || array_key_exists("evenementss", $context) ? $context["evenementss"] : (function () { throw new RuntimeError('Variable "evenementss" does not exist.', 64, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["evenement"]) {
            // line 65
            echo "
                                <tr>
                                    <td>";
            // line 67
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["evenement"], "nom", [], "any", false, false, false, 67), "html", null, true);
            echo "</td>
                                    <td>";
            // line 68
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["evenement"], "nbreDeplaces", [], "any", false, false, false, 68), "html", null, true);
            echo "</td>
                                    <td>";
            // line 69
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["evenement"], "type", [], "any", false, false, false, 69), "html", null, true);
            echo "</td>
                                    <td>";
            // line 70
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["evenement"], "prix", [], "any", false, false, false, 70), "html", null, true);
            echo "</td>
                                    <td>";
            // line 71
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["evenement"], "date", [], "any", false, false, false, 71), "d-m-Y"), "html", null, true);
            echo "</td>


                                    <td>
                                        <a href=\"";
            // line 75
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("update", ["id" => twig_get_attribute($this->env, $this->source, $context["evenement"], "id", [], "any", false, false, false, 75)]), "html", null, true);
            echo "\" class=\"edit\" title=\"Edit\"
                                            data-toggle=\"tooltip\">
                                            <i class=\"material-icons\">&#xE254;</i>
                                        </a>
                                        <a href=\"\" class=\"delete\" data-toggle=\"modal\"
                                            data-target=\"#deleteModal-";
            // line 80
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["evenement"], "id", [], "any", false, false, false, 80), "html", null, true);
            echo "\">
                                            <i class=\"material-icons\">&#xE872;</i>
                                        </a>
                                        <div class=\"modal fade\" id=\"deleteModal-";
            // line 83
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["evenement"], "id", [], "any", false, false, false, 83), "html", null, true);
            echo "\" tabindex=\"-1\"
                                            role=\"dialog\" aria-labelledby=\"deleteModalLabel\" aria-hidden=\"true\">
                                            <div class=\"modal-dialog\" role=\"document\">
                                                <div class=\"modal-content\">
                                                    <div class=\"modal-header\">
                                                        <h5 class=\"modal-title\" id=\"deleteModalLabel\">Voulez vous
                                                            supprimer ce evenement?</h5>
                                                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\"
                                                            aria-label=\"Close\">
                                                            <span aria-hidden=\"true\">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class=\"modal-footer\">
                                                        <button type=\"button\" class=\"btn btn-secondary\"
                                                            data-dismiss=\"modal\">Annuler</button>
                                                        <form
                                                            action=\"";
            // line 99
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("SupprimerEvent", ["id" => twig_get_attribute($this->env, $this->source, $context["evenement"], "id", [], "any", false, false, false, 99)]), "html", null, true);
            echo "\"
                                                            method=\"POST\">
                                                            <input class=\"btn btn-danger\" type=\"submit\"
                                                                value=\"Supprimer\">
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>

                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['evenement'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 112
        echo "                            </tbody>
                            </tbody>
                        </table>

                    </div>
                    <h1>Event Attendance Statistics</h1>
                    <canvas id=\"myChart\" width=\"800\" height=\"400\"></canvas>
                </div>
            </div>
        </div>
    </div>
    <script src=\"https://cdn.jsdelivr.net/npm/chart.js\"></script>
    <script>
        var ctx = document.getElementById('myChart').getContext('2d');
        var chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ";
        // line 129
        echo json_encode((isset($context["event_dates"]) || array_key_exists("event_dates", $context) ? $context["event_dates"] : (function () { throw new RuntimeError('Variable "event_dates" does not exist.', 129, $this->source); })()));
        echo ",
                datasets: [{
                    label: 'Event Attendance',
                    data: ";
        // line 132
        echo json_encode((isset($context["event_attendance"]) || array_key_exists("event_attendance", $context) ? $context["event_attendance"] : (function () { throw new RuntimeError('Variable "event_attendance" does not exist.', 132, $this->source); })()));
        echo ",
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    </script>
    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "evenement/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  283 => 132,  277 => 129,  258 => 112,  239 => 99,  220 => 83,  214 => 80,  206 => 75,  199 => 71,  195 => 70,  191 => 69,  187 => 68,  183 => 67,  179 => 65,  175 => 64,  148 => 40,  137 => 31,  127 => 30,  94 => 6,  89 => 5,  79 => 4,  60 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Evenement{% endblock %}
{% block StyleAfterTemplate %}
<link href=\"{{asset('https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css')}}\" rel=\"stylesheet\" />
<link rel=\"stylesheet\" href=\"{{asset('https://fonts.googleapis.com/icon?family=Material+Icons')}}\">
<style>
    /* Table actions icons*/
    table.table td a.view {
        color: #03A9F4;
    }

    table.table td a.edit {
        color: #FFC107;
    }

    table.table td a.delete {
        color: #E34724;
        text-align: center;
    }

    .hint-text {
        float: left;
        margin-top: 6px;
        font-size: 95%;
    }
</style>
{% endblock StyleAfterTemplate %}

{% block body %}
<div class=\"row justify-content-md-center\">

    <div class=\"col-lg-11\">
        <div class=\"card o-hidden border-0 shadow-lg my-5\">
            <div class=\"card-body p-0\">
                <div class=\"p-5\">
                    <div class=\"text-center\">
                        <h1 class=\"h4 text-gray-900 mb-4\">Les Evenements</h1>
                    </div>
                    <a href=\"{{ path('AjouterEvent') }}\" class=\"btn btn-success btn float-right col-sm col-md-3\">
                        <span class=\"icon text-white-50\">
                            <i style=\"float: left;\" class=\"material-icons mr-2\">&#xE147;</i>
                        </span>
                        <span class=\"text\">Ajouter un evenement</span>
                    </a>
                    <div class=\"table-responsive-sm mt-4\">
                        <div class=\"d-none d-sm-inline-block form-inline navbar-search\">

                        </div>
                        <br>
                        <br>
                        <table class=\"table table-hover \" id=\"myTable\">
                            <thead class=\"thead-light \">
                                <tr>
                                    <th scope=\"col\">Nom</th>
                                    <th scope=\"col\">nombre de places</th>
                                    <th scope=\"col\">type</th>
                                    <th scope=\"col\">prix</th>
                                    <th scope=\"col\">Date</th>
                                    <th scope=\"col\">Action</th>
                                </tr>
                            </thead>
                            <tbody id=\"myTable\">
                                {% for evenement in evenementss %}

                                <tr>
                                    <td>{{ evenement.nom }}</td>
                                    <td>{{ evenement.nbreDeplaces }}</td>
                                    <td>{{ evenement.type }}</td>
                                    <td>{{ evenement.prix }}</td>
                                    <td>{{ evenement.date |date('d-m-Y') }}</td>


                                    <td>
                                        <a href=\"{{ path('update', {'id':evenement.id }) }}\" class=\"edit\" title=\"Edit\"
                                            data-toggle=\"tooltip\">
                                            <i class=\"material-icons\">&#xE254;</i>
                                        </a>
                                        <a href=\"\" class=\"delete\" data-toggle=\"modal\"
                                            data-target=\"#deleteModal-{{ evenement.id }}\">
                                            <i class=\"material-icons\">&#xE872;</i>
                                        </a>
                                        <div class=\"modal fade\" id=\"deleteModal-{{ evenement.id }}\" tabindex=\"-1\"
                                            role=\"dialog\" aria-labelledby=\"deleteModalLabel\" aria-hidden=\"true\">
                                            <div class=\"modal-dialog\" role=\"document\">
                                                <div class=\"modal-content\">
                                                    <div class=\"modal-header\">
                                                        <h5 class=\"modal-title\" id=\"deleteModalLabel\">Voulez vous
                                                            supprimer ce evenement?</h5>
                                                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\"
                                                            aria-label=\"Close\">
                                                            <span aria-hidden=\"true\">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class=\"modal-footer\">
                                                        <button type=\"button\" class=\"btn btn-secondary\"
                                                            data-dismiss=\"modal\">Annuler</button>
                                                        <form
                                                            action=\"{{ path('SupprimerEvent', {'id':evenement.id }) }}\"
                                                            method=\"POST\">
                                                            <input class=\"btn btn-danger\" type=\"submit\"
                                                                value=\"Supprimer\">
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>

                                {% endfor %}
                            </tbody>
                            </tbody>
                        </table>

                    </div>
                    <h1>Event Attendance Statistics</h1>
                    <canvas id=\"myChart\" width=\"800\" height=\"400\"></canvas>
                </div>
            </div>
        </div>
    </div>
    <script src=\"https://cdn.jsdelivr.net/npm/chart.js\"></script>
    <script>
        var ctx = document.getElementById('myChart').getContext('2d');
        var chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: {{ event_dates|json_encode|raw }},
                datasets: [{
                    label: 'Event Attendance',
                    data: {{ event_attendance|json_encode|raw }},
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    </script>
    {% endblock %}", "evenement/index.html.twig", "/home/ilyes/Documents/Pi_ModuleEvenement_Offre_Farah/templates/evenement/index.html.twig");
    }
}
