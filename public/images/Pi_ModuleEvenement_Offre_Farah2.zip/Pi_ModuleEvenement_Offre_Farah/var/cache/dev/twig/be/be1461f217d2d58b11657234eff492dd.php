<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* offre/index.html.twig */
class __TwigTemplate_f6c255743d821e399a2736729277b232 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'StyleAfterTemplate' => [$this, 'block_StyleAfterTemplate'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "offre/index.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "offre/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "offre/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 2
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "offre";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 3
    public function block_StyleAfterTemplate($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "StyleAfterTemplate"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "StyleAfterTemplate"));

        // line 4
        echo "<link href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" />
<link rel=\"stylesheet\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("https://fonts.googleapis.com/icon?family=Material+Icons"), "html", null, true);
        echo "\">
<style>
    /* Table actions icons*/
    table.table td a.view {
        color: #03A9F4;
    }

    table.table td a.edit {
        color: #FFC107;
    }

    table.table td a.delete {
        color: #E34724;
        text-align: center;
    }

    .hint-text {
        float: left;
        margin-top: 6px;
        font-size: 95%;
    }
</style>
    <link rel=\"stylesheet\" href=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("https://cdn.jsdelivr.net/npm/@fullcalendar/core@4.1.0/main.min.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@4.1.0/main.min.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@4.1.0/main.min.css"), "html", null, true);
        echo "\">


";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 33
    public function block_stylesheets($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 36
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 37
        echo "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 40
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 41
        echo "<div class=\"row justify-content-md-center\">

    <div class=\"col-lg-11\">
        <div class=\"card o-hidden border-0 shadow-lg my-5\">
            <div class=\"card-body p-0\">
                <div class=\"p-5\">
                    <div class=\"text-center\">
                        <h1 class=\"h4 text-gray-900 mb-4\">Les Offres</h1>

                    </div>
                    <a href=\"";
        // line 51
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("Ajouteroffre");
        echo "\" class=\"btn btn-success btn float-right col-sm col-md-3\">
                        <span class=\"icon text-white-50\">
                            <i style=\"float: left;\" class=\"material-icons mr-2\">&#xE147;</i>
                        </span>
                        <span class=\"text\">Ajouter un Offre</span>
                    </a>
                    <div class=\"table-responsive-sm mt-4\">
                        <div class=\"d-none d-sm-inline-block form-inline navbar-search\">

                        </div>
                        <br>
                        <br>
                        <form method=\"get\" action=\"";
        // line 63
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("listOffre");
        echo "\">
                            <div class=\"form-group\">
                                <input type=\"text\" class=\"form-control\" name=\"q\" value=\"";
        // line 65
        echo twig_escape_filter($this->env, (isset($context["query"]) || array_key_exists("query", $context) ? $context["query"] : (function () { throw new RuntimeError('Variable "query" does not exist.', 65, $this->source); })()), "html", null, true);
        echo "\">
                            </div>
                            <button type=\"submit\" class=\"btn btn-primary\">Search</button>
                        </form>

                        <table class=\"table table-hover \" id=\"myTable\">
                            <thead class=\"thead-light \">
                                <tr>
                                    <th scope=\"col\"><a href=\"?sort=nom&dir=";
        // line 73
        echo ((((isset($context["dir"]) || array_key_exists("dir", $context) ? $context["dir"] : (function () { throw new RuntimeError('Variable "dir" does not exist.', 73, $this->source); })()) == "asc")) ? ("desc") : ("asc"));
        echo "\">Nom</a></th>
                                    <th scope=\"col\"><a href=\"?sort=dateDatedeb&dir=";
        // line 74
        echo ((((isset($context["dir"]) || array_key_exists("dir", $context) ? $context["dir"] : (function () { throw new RuntimeError('Variable "dir" does not exist.', 74, $this->source); })()) == "asc")) ? ("desc") : ("asc"));
        echo "\">Date Debut</a></th>
                                    <th scope=\"col\"><a href=\"?sort=dateFin&dir=";
        // line 75
        echo ((((isset($context["dir"]) || array_key_exists("dir", $context) ? $context["dir"] : (function () { throw new RuntimeError('Variable "dir" does not exist.', 75, $this->source); })()) == "asc")) ? ("desc") : ("asc"));
        echo "\">Date Fin</a></th>
                                    <th scope=\"col\"><a href=\"?sort=pourcentage&dir=";
        // line 76
        echo ((((isset($context["dir"]) || array_key_exists("dir", $context) ? $context["dir"] : (function () { throw new RuntimeError('Variable "dir" does not exist.', 76, $this->source); })()) == "asc")) ? ("desc") : ("asc"));
        echo "\">Pourcentage</a></th>
                                    <th scope=\"col\">Action</th>
                                </tr>
                            </thead>
                            <tbody id=\"myTable\">
                                ";
        // line 81
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["offress"]) || array_key_exists("offress", $context) ? $context["offress"] : (function () { throw new RuntimeError('Variable "offress" does not exist.', 81, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["offre"]) {
            // line 82
            echo "
                                <tr>
                                    <td>";
            // line 84
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["offre"], "nom", [], "any", false, false, false, 84), "html", null, true);
            echo "</td>
                                    <td>";
            // line 85
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["offre"], "dateDatedeb", [], "any", false, false, false, 85), "d-m-Y"), "html", null, true);
            echo "</td>
                                    <td>";
            // line 86
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["offre"], "dateFin", [], "any", false, false, false, 86), "d-m-Y"), "html", null, true);
            echo "</td>
                                    <td>";
            // line 87
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["offre"], "pourcentage", [], "any", false, false, false, 87), "html", null, true);
            echo "</td>
                                  
                                    <td>
                                        <a href=\"";
            // line 90
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("updateO", ["id" => twig_get_attribute($this->env, $this->source, $context["offre"], "idOffre", [], "any", false, false, false, 90)]), "html", null, true);
            echo "\" class=\"edit\" title=\"Edit\"
                                            data-toggle=\"tooltip\">
                                            <i class=\"material-icons\">&#xE254;</i>
                                        </a>
                                        <a href=\"\" class=\"delete\" data-toggle=\"modal\"
                                            data-target=\"#deleteModal-";
            // line 95
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["offre"], "idOffre", [], "any", false, false, false, 95), "html", null, true);
            echo "\">
                                            <i class=\"material-icons\">&#xE872;</i>
                                        </a>
                                        <div class=\"modal fade\" id=\"deleteModal-";
            // line 98
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["offre"], "idOffre", [], "any", false, false, false, 98), "html", null, true);
            echo "\" tabindex=\"-1\"
                                            role=\"dialog\" aria-labelledby=\"deleteModalLabel\" aria-hidden=\"true\">
                                            <div class=\"modal-dialog\" role=\"document\">
                                                <div class=\"modal-content\">
                                                    <div class=\"modal-header\">
                                                        <h5 class=\"modal-title\" id=\"deleteModalLabel\">Voulez vous
                                                            supprimer ce offre?</h5>
                                                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\"
                                                            aria-label=\"Close\">
                                                            <span aria-hidden=\"true\">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class=\"modal-footer\">
                                                        <button type=\"button\" class=\"btn btn-secondary\"
                                                            data-dismiss=\"modal\">Annuler</button>
                                                        <form
                                                            action=\"";
            // line 114
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("SupprimerOffre", ["id" => twig_get_attribute($this->env, $this->source, $context["offre"], "idOffre", [], "any", false, false, false, 114)]), "html", null, true);
            echo "\"
                                                            method=\"POST\">
                                                            <input class=\"btn btn-danger\" type=\"submit\"
                                                                value=\"Supprimer\">
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>

                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['offre'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 127
        echo "                            </tbody>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
                <div class=\"card-body p-0\">
                    <div id=\"calendar-holder\"></div>
                </div>
        </div>
    </div>
</div>
    <script src=\"https://cdn.jsdelivr.net/npm/@fullcalendar/core@4.1.0/main.min.js\"></script>
    <script src=\"https://cdn.jsdelivr.net/npm/@fullcalendar/interaction@4.1.0/main.min.js\"></script>
    <script src=\"https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@4.1.0/main.min.js\"></script>
    <script src=\"https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@4.1.0/main.min.js\"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            var calendarEl = document.getElementById('calendar-holder');

            var calendar = new FullCalendar.Calendar(calendarEl, {
                defaultView: 'dayGridMonth',
                editable: true,
                eventSources: [
                    {
                        url: \"/calendar/loadEvents\", // Updated URL path
                        method: \"POST\",
                        extraParams: {
                            filters: JSON.stringify({})
                        },
                        failure: () => {
                            //
                            //
                            alert(\"There was an error while fetching FullCalendar!\");
                        },
                    },
                ],
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay',
                },
                plugins: ['interaction', 'dayGrid', 'timeGrid'], // https://fullcalendar.io/docs/plugin-index
                timeZone: 'UTC',
            });
            calendar.render();
            console.log(calendar);
        });

    </script>
    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "offre/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  333 => 127,  314 => 114,  295 => 98,  289 => 95,  281 => 90,  275 => 87,  271 => 86,  267 => 85,  263 => 84,  259 => 82,  255 => 81,  247 => 76,  243 => 75,  239 => 74,  235 => 73,  224 => 65,  219 => 63,  204 => 51,  192 => 41,  182 => 40,  171 => 37,  161 => 36,  143 => 33,  129 => 29,  125 => 28,  121 => 27,  96 => 5,  91 => 4,  81 => 3,  62 => 2,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block title %}offre{% endblock %}
{% block StyleAfterTemplate %}
<link href=\"{{asset('https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css')}}\" rel=\"stylesheet\" />
<link rel=\"stylesheet\" href=\"{{asset('https://fonts.googleapis.com/icon?family=Material+Icons')}}\">
<style>
    /* Table actions icons*/
    table.table td a.view {
        color: #03A9F4;
    }

    table.table td a.edit {
        color: #FFC107;
    }

    table.table td a.delete {
        color: #E34724;
        text-align: center;
    }

    .hint-text {
        float: left;
        margin-top: 6px;
        font-size: 95%;
    }
</style>
    <link rel=\"stylesheet\" href=\"{{ asset('https://cdn.jsdelivr.net/npm/@fullcalendar/core@4.1.0/main.min.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@4.1.0/main.min.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@4.1.0/main.min.css') }}\">


{% endblock StyleAfterTemplate %}
{% block stylesheets %}
{% endblock %}

{% block javascripts %}

{% endblock %}

{% block body %}
<div class=\"row justify-content-md-center\">

    <div class=\"col-lg-11\">
        <div class=\"card o-hidden border-0 shadow-lg my-5\">
            <div class=\"card-body p-0\">
                <div class=\"p-5\">
                    <div class=\"text-center\">
                        <h1 class=\"h4 text-gray-900 mb-4\">Les Offres</h1>

                    </div>
                    <a href=\"{{ path('Ajouteroffre') }}\" class=\"btn btn-success btn float-right col-sm col-md-3\">
                        <span class=\"icon text-white-50\">
                            <i style=\"float: left;\" class=\"material-icons mr-2\">&#xE147;</i>
                        </span>
                        <span class=\"text\">Ajouter un Offre</span>
                    </a>
                    <div class=\"table-responsive-sm mt-4\">
                        <div class=\"d-none d-sm-inline-block form-inline navbar-search\">

                        </div>
                        <br>
                        <br>
                        <form method=\"get\" action=\"{{ path('listOffre') }}\">
                            <div class=\"form-group\">
                                <input type=\"text\" class=\"form-control\" name=\"q\" value=\"{{ query }}\">
                            </div>
                            <button type=\"submit\" class=\"btn btn-primary\">Search</button>
                        </form>

                        <table class=\"table table-hover \" id=\"myTable\">
                            <thead class=\"thead-light \">
                                <tr>
                                    <th scope=\"col\"><a href=\"?sort=nom&dir={{ dir == 'asc' ? 'desc' : 'asc' }}\">Nom</a></th>
                                    <th scope=\"col\"><a href=\"?sort=dateDatedeb&dir={{ dir == 'asc' ? 'desc' : 'asc' }}\">Date Debut</a></th>
                                    <th scope=\"col\"><a href=\"?sort=dateFin&dir={{ dir == 'asc' ? 'desc' : 'asc' }}\">Date Fin</a></th>
                                    <th scope=\"col\"><a href=\"?sort=pourcentage&dir={{ dir == 'asc' ? 'desc' : 'asc' }}\">Pourcentage</a></th>
                                    <th scope=\"col\">Action</th>
                                </tr>
                            </thead>
                            <tbody id=\"myTable\">
                                {% for offre in offress %}

                                <tr>
                                    <td>{{ offre.nom }}</td>
                                    <td>{{ offre.dateDatedeb |date('d-m-Y') }}</td>
                                    <td>{{ offre.dateFin |date('d-m-Y') }}</td>
                                    <td>{{ offre.pourcentage }}</td>
                                  
                                    <td>
                                        <a href=\"{{ path('updateO', {'id':offre.idOffre }) }}\" class=\"edit\" title=\"Edit\"
                                            data-toggle=\"tooltip\">
                                            <i class=\"material-icons\">&#xE254;</i>
                                        </a>
                                        <a href=\"\" class=\"delete\" data-toggle=\"modal\"
                                            data-target=\"#deleteModal-{{ offre.idOffre }}\">
                                            <i class=\"material-icons\">&#xE872;</i>
                                        </a>
                                        <div class=\"modal fade\" id=\"deleteModal-{{ offre.idOffre }}\" tabindex=\"-1\"
                                            role=\"dialog\" aria-labelledby=\"deleteModalLabel\" aria-hidden=\"true\">
                                            <div class=\"modal-dialog\" role=\"document\">
                                                <div class=\"modal-content\">
                                                    <div class=\"modal-header\">
                                                        <h5 class=\"modal-title\" id=\"deleteModalLabel\">Voulez vous
                                                            supprimer ce offre?</h5>
                                                        <button type=\"button\" class=\"close\" data-dismiss=\"modal\"
                                                            aria-label=\"Close\">
                                                            <span aria-hidden=\"true\">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class=\"modal-footer\">
                                                        <button type=\"button\" class=\"btn btn-secondary\"
                                                            data-dismiss=\"modal\">Annuler</button>
                                                        <form
                                                            action=\"{{ path('SupprimerOffre', {'id':offre.idOffre }) }}\"
                                                            method=\"POST\">
                                                            <input class=\"btn btn-danger\" type=\"submit\"
                                                                value=\"Supprimer\">
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>

                                {% endfor %}
                            </tbody>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
                <div class=\"card-body p-0\">
                    <div id=\"calendar-holder\"></div>
                </div>
        </div>
    </div>
</div>
    <script src=\"https://cdn.jsdelivr.net/npm/@fullcalendar/core@4.1.0/main.min.js\"></script>
    <script src=\"https://cdn.jsdelivr.net/npm/@fullcalendar/interaction@4.1.0/main.min.js\"></script>
    <script src=\"https://cdn.jsdelivr.net/npm/@fullcalendar/daygrid@4.1.0/main.min.js\"></script>
    <script src=\"https://cdn.jsdelivr.net/npm/@fullcalendar/timegrid@4.1.0/main.min.js\"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            var calendarEl = document.getElementById('calendar-holder');

            var calendar = new FullCalendar.Calendar(calendarEl, {
                defaultView: 'dayGridMonth',
                editable: true,
                eventSources: [
                    {
                        url: \"/calendar/loadEvents\", // Updated URL path
                        method: \"POST\",
                        extraParams: {
                            filters: JSON.stringify({})
                        },
                        failure: () => {
                            //
                            //
                            alert(\"There was an error while fetching FullCalendar!\");
                        },
                    },
                ],
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,timeGridDay',
                },
                plugins: ['interaction', 'dayGrid', 'timeGrid'], // https://fullcalendar.io/docs/plugin-index
                timeZone: 'UTC',
            });
            calendar.render();
            console.log(calendar);
        });

    </script>
    {% endblock %}
", "offre/index.html.twig", "/home/ilyes/Documents/Pi_ModuleEvenement_Offre_Farah/templates/offre/index.html.twig");
    }
}
