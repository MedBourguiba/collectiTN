<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/listeevenement' => [[['_route' => 'listeevenement', '_controller' => 'App\\Controller\\EvenementController::afficher'], null, null, null, false, false, null]],
        '/Ajouterevenement' => [[['_route' => 'AjouterEvent', '_controller' => 'App\\Controller\\EvenementController::AjouterEvent'], null, null, null, false, false, null]],
        '/offre' => [[['_route' => 'app_offre', '_controller' => 'App\\Controller\\OffreController::index'], null, null, null, false, false, null]],
        '/calendar/loadEvents' => [[['_route' => 'calendar_load_events', '_controller' => 'App\\Controller\\OffreController::loadEvents'], null, null, null, false, false, null]],
        '/Listoffre' => [[['_route' => 'listOffre', '_controller' => 'App\\Controller\\OffreController::afficher'], null, null, null, false, false, null]],
        '/Ajouteroffre' => [[['_route' => 'Ajouteroffre', '_controller' => 'App\\Controller\\OffreController::AjouterEvent'], null, null, null, false, false, null]],
        '/fc-load-events' => [[['_route' => 'fc_load_events', '_controller' => 'CalendarBundle\\Controller\\CalendarController::loadAction'], null, null, null, false, false, null]],
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/Supprimer(?'
                    .'|evenement/([^/]++)(*:38)'
                    .'|Offre/([^/]++)(*:59)'
                .')'
                .'|/Update(?'
                    .'|evenement/([^/]++)(*:95)'
                    .'|Offre/([^/]++)(*:116)'
                .')'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:156)'
                    .'|wdt/([^/]++)(*:176)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:222)'
                            .'|router(*:236)'
                            .'|exception(?'
                                .'|(*:256)'
                                .'|\\.css(*:269)'
                            .')'
                        .')'
                        .'|(*:279)'
                    .')'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => 'SupprimerEvent', '_controller' => 'App\\Controller\\EvenementController::supprimer'], ['id'], null, null, false, true, null]],
        59 => [[['_route' => 'SupprimerOffre', '_controller' => 'App\\Controller\\OffreController::supprimer'], ['id'], null, null, false, true, null]],
        95 => [[['_route' => 'update', '_controller' => 'App\\Controller\\EvenementController::update'], ['id'], null, null, false, true, null]],
        116 => [[['_route' => 'updateO', '_controller' => 'App\\Controller\\OffreController::update'], ['id'], null, null, false, true, null]],
        156 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        176 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        222 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        236 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        256 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        269 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        279 => [
            [['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
